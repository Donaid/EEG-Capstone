from mindwavelsl.outlet import MindwaveLSL

__all__ = ['MindwaveLSL']
